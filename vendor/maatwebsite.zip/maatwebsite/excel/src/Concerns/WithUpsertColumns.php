<?php

namespace Maatwebsite\Excel\Concerns;

interface WithUpsertColumns
{
    /**
     * @return array
     */
    public function upsertColumns();
}
